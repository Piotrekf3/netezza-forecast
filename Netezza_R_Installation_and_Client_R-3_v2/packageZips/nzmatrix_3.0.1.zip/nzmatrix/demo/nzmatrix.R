# 
# Copyright (c) 2010, 2014, IBM Corp. All rights reserved. 
#     
# This program is free software: you can redistribute it and/or modify 
# it under the terms of the GNU General Public License as published by 
# the Free Software Foundation, either version 3 of the License, or 
# (at your option) any later version. 
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
# GNU General Public License for more details. 
#
# You should have received a copy of the GNU General Public License 
# along with this program. If not, see <http://www.gnu.org/licenses/>. 
#

if (!any(names(odbcDataSources()) == 'NZSQL')) {
  simpleError("The NZSQL DSN have to be defined!")
}

nzDisconnect()
nzConnectDSN('NZSQL')

nzMatrixEngineInitialization()

if (!nzExistMatrixByName("RCV2IRIS")) {
   # link to existing nzmatrix
   nziris = as.nz.matrix(as.matrix(iris[,1:4]), "RCV2IRIS")
} else {
   # uploading nzmatrix
   nziris = nz.matrix("RCV2IRIS")
}

################################################################
# Investigation for matrix properties

dim(nziris)
nzRand = nzNormalMatrix(10, 10, "nzRand")
# nzIdentityMatrix(5,"I5")
# nzRandomMatrix
# nzOnesMatrix


nzRand2 = nzCBind(nzRand, nzRand)

as.matrix(firstRows  <- nzRand2[1:3,])
as.matrix(firstCols  <- nzRand2[,1:3])
as.matrix(nzRand2[4,5])

nzDeleteMatrix(firstRows)
nzDeleteMatrix(firstCols)

# HIT ENTER
invisible(readline())

################################################################
# Elementwise operations

as.matrix(exp(nzRand2))
as.matrix(trunc(nzRand2))
# sqrt()
# abs()
# ceiling()
# floor()
# mod()
# abs()
# rounding()

as.matrix(nzElementwiseMatrixOperations(nzRand2, "*", 3))

# HIT ENTER
invisible(readline())

################################################################
# Matrix reductors

nzMax(nzRand2)
nzMin(nzRand2)
nzSsq(nzRand2)
nzSum(nzRand2)
nzTr(nzRand)


# HIT ENTER
invisible(readline())

################################################################
# Matrix algebra operations

# SVD used for PCA
nzRand3 = nzNormalMatrix(1000, 2) %*% nzNormalMatrix(2, 1000)
svdR3 = nzSVD(nzRand3)
as.matrix(svdR3$s)
# transfornmation matrix
svdR3$s
# PCA
nzNewVar = (nzRand3 %*% svdR3$v)[,1:2]
plot(as.matrix(nzNewVar))

# solve used for linear regression
nzRand3 = nzNormalMatrix(1000, 100)
X = nzRand3 [,1:99]
Y = nzRand3 [,100]
XTX = t(X) %*% X
XTY = t(X) %*% Y
beta = nzSolve(XTX, XTY)


nzDisconnect()

